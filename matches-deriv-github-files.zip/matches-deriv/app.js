(() => {
  const $ = id => document.getElementById(id);
  let socket = null;
  let running = false;
  let liveTicks = [];
  let historyTicks = [];
  let requestId = 0;
  let pendingHistoryId = null;

  for (let d = 0; d <= 9; d++) {
    const option = document.createElement("option");
    option.value = String(d);
    option.textContent = String(d);
    $("targetDigit").appendChild(option);
  }

  function setStatus(text, state = "") {
    $("statusPill").textContent = text;
    $("statusPill").className = "status-pill" + (state ? " " + state : "");
  }

  // Deriv quotes are decimal-formatted. The final displayed decimal digit is used.
  function getLastDigit(quote) {
    const value = String(quote);
    const decimals = value.includes(".") ? value.split(".")[1] : "";
    return Number((decimals || "0").slice(-1));
  }

  function currentSample() {
    const count = Number($("tickCount").value);
    const source = historyTicks.length ? historyTicks : liveTicks;
    return source.slice(-count);
  }

  function render() {
    const sample = currentSample();
    const counts = Array(10).fill(0);
    sample.forEach(t => counts[t.digit]++);
    $("total").textContent = String(sample.length);

    $("frequency").innerHTML = counts.map((count, digit) => {
      const percent = sample.length ? (count * 100 / sample.length).toFixed(1) : "0.0";
      return `<div class="digit-card" tabindex="0">
        <div class="digit-number">${digit}</div>
        <div class="digit-count">${count} ticks</div>
        <div class="digit-percent">${percent}%</div>
      </div>`;
    }).join("");

    if (sample.length) {
      const max = Math.max(...counts);
      const winners = counts.map((n, d) => n === max ? d : null).filter(d => d !== null);
      $("mostFrequent").textContent = `${winners.join(", ")} (${max} occurrence${max === 1 ? "" : "s"})`;
    } else {
      $("mostFrequent").textContent = "—";
    }

    const target = Number($("targetDigit").value);
    const matchCount = sample.filter(t => t.digit === target).length;
    const differCount = sample.length - matchCount;
    $("matches").textContent = sample.length
      ? `${matchCount} · ${(100 * matchCount / sample.length).toFixed(1)}%` : "—";
    $("differs").textContent = sample.length
      ? `${differCount} · ${(100 * differCount / sample.length).toFixed(1)}%` : "—";

    $("recent").innerHTML = sample.slice(-30).reverse().map(t =>
      `<span class="tick" title="Quote: ${t.quote}">${t.digit}</span>`
    ).join("") || '<span class="muted">Waiting for data…</span>';
  }

  function closeSocket() {
    if (socket) {
      const old = socket;
      socket = null;
      old.onclose = null;
      old.onerror = null;
      old.close();
    }
  }

  function connect() {
    closeSocket();
    running = true;
    historyTicks = [];
    liveTicks = [];
    pendingHistoryId = null;
    $("quote").textContent = "—";
    $("digit").textContent = "—";
    $("liveCount").textContent = "0";
    $("historyStatus").textContent = "Connected to live stream to load history.";
    render();
    setStatus("Connecting…");
    $("connectionMessage").textContent = "Opening public market-data connection…";

    // Public market-data endpoint; no API token is included in this static app.
    socket = new WebSocket("wss://api.derivws.com/trading/v1/options/ws/public");

    socket.onopen = () => {
      if (!running || !socket) return;
      setStatus("Connected", "connected");
      $("connectionMessage").textContent = "Connected. Waiting for the first tick…";
      socket.send(JSON.stringify({
        ticks: $("market").value,
        subscribe: 1,
        req_id: ++requestId
      }));
    };

    socket.onmessage = event => {
      if (!running) return;
      let data;
      try { data = JSON.parse(event.data); } catch { return; }

      if (data.error) {
        setStatus("API error", "error");
        $("connectionMessage").textContent = data.error.message || "The data service returned an error.";
        if (data.req_id === pendingHistoryId) {
          pendingHistoryId = null;
          $("historyStatus").textContent = "Could not load history: " + (data.error.message || "API error");
        }
        return;
      }

      if (data.history && data.prices) {
        const prices = data.prices;
        const times = data.times || [];
        historyTicks = prices.map((quote, i) => ({
          quote: String(quote),
          digit: getLastDigit(quote),
          time: times[i] || 0
        }));
        pendingHistoryId = null;
        $("historyStatus").textContent = `Loaded ${historyTicks.length} historical ticks.`;
        render();
        return;
      }

      if (data.tick) {
        const quote = String(data.tick.quote);
        liveTicks.push({ quote, digit: getLastDigit(quote), time: data.tick.epoch || 0 });
        if (liveTicks.length > 5000) liveTicks.shift();
        $("quote").textContent = quote;
        $("digit").textContent = String(getLastDigit(quote));
        $("liveCount").textContent = String(liveTicks.length);
        $("connectionMessage").textContent = "Receiving live ticks. Historical analysis is loaded separately.";
        if (!historyTicks.length) render();
      }
    };

    socket.onerror = () => {
      setStatus("Connection error", "error");
      $("connectionMessage").textContent = "Connection failed. Check your internet connection and the current Deriv public API endpoint.";
    };

    socket.onclose = () => {
      if (running) {
        setStatus("Connection closed", "error");
        $("connectionMessage").textContent = "The WebSocket closed. The public endpoint or request format may need updating.";
      } else {
        setStatus("Disconnected");
      }
    };
  }

  function stop() {
    running = false;
    pendingHistoryId = null;
    closeSocket();
    setStatus("Disconnected");
    $("connectionMessage").textContent = "Connection stopped.";
  }

  function loadHistory() {
    if (!socket || socket.readyState !== WebSocket.OPEN) {
      $("historyStatus").textContent = "Connect to live data first.";
      return;
    }
    pendingHistoryId = ++requestId;
    historyTicks = [];
    $("historyStatus").textContent = "Requesting historical ticks…";
    socket.send(JSON.stringify({
      ticks_history: $("market").value,
      count: Number($("tickCount").value),
      end: "latest",
      style: "ticks",
      req_id: pendingHistoryId
    }));
  }

  $("startBtn").addEventListener("click", connect);
  $("stopBtn").addEventListener("click", stop);
  $("historyBtn").addEventListener("click", loadHistory);
  $("targetDigit").addEventListener("change", render);
  $("tickCount").addEventListener("change", () => {
    if (historyTicks.length) {
      historyTicks = historyTicks.slice(-Number($("tickCount").value));
      render();
    } else {
      render();
    }
  });
  $("market").addEventListener("change", () => { if (running) connect(); });
  $("themeBtn").addEventListener("click", () => document.body.classList.toggle("alt"));
  render();
})();
